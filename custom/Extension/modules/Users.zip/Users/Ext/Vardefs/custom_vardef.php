<?php

       //$dictionary['User']['fields'] ['reports_to_name']['massupdate'] = false;
       $dictionary['User']['fields'] ['is_admin']['massupdate'] = false;
       $dictionary['User']['fields'] ['company_name'] = array(	'name' => 'company_name',
													       		'label' => 'LBL_COMPANY',
													       		'type' => 'varchar',
													       		'len' => '250'
													       		
													       		);
      // $dictionary['User']['fields']['email1']['function']=array('name' => 'getEmailAddressWidgetCustom','returns' => 'html');
        
?>