<?php
global $arUserRoleConfig;
 $arUserRoleConfig = array(
                     'opp_reviewer'=>'c542cb6b-9cec-3f4b-5a5b-4e65fad23413' ,
                     'lead_reviewer' =>'cabc05d6-182b-c199-58de-4e65fa6ec131',
                    'full_pipeline' => 'ced1c55c-40ac-7c8a-7f71-4e65fa2d30ea',
                  // 'team_manager' => 'f137969a-8119-b995-5e7d-4eeecdd49bfd'
                    'team_manager' => 'b6849361-b86a-fe6f-0903-4e65facc1aa7'

                );
?>