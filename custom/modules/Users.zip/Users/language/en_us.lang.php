<?php
// created: 2019-11-27 10:19:58
$mod_strings = array (
  'LBL_CONTACTS_SYNC' => 'Client Contacts Sync',
);