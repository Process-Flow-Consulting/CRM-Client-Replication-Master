<?php
// created: 2013-10-09 09:09:14
$key = array (
  0 => '6af134ed-97ab-4567-206d-52551d4503d5',
);