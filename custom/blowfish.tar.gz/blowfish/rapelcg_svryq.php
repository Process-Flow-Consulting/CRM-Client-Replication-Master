<?php
// created: 2013-10-09 09:09:14
$key = array (
  0 => '626674c2-fde1-adce-d585-52551dc4d93e',
);